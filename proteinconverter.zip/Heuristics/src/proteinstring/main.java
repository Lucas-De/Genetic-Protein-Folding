package proteinstring;

import java.util.Scanner;

public class main {

	main() {
		String protein = "H4P4H12P6H12P3H12P3H12P3HP2H2P2H2P2HPH";
		String printthis = toString(protein);
		System.out.println("length is: " + printthis.length());
	}
	
	private String toString(String protein) {
		String awnser = "";
		char a;
		char number1;
		char number2;
		String finalnumber = "";
		char state;
		for(int i = 0; i< protein.length()-1;i++){
			a='a';
			number1 = 0;
			number2 = 0;
			finalnumber = "";
			state='x';
			if(protein.charAt(i) >= 'A' && protein.charAt(i) <= 'Z'){
				a = protein.charAt(i);
				state = 'a';
				if (protein.charAt(i+1) >= '1' && protein.charAt(i+1) <= '9'){
					number1 = protein.charAt(i+1);
					finalnumber = "" + number1;
					state = 'b';
					if (protein.charAt(i+2) >= '0' && protein.charAt(i+2) <= '9'){
						number2 = protein.charAt(i+2);
						finalnumber = "" + number1 + number2;
						state = 'b';
					}	
				}
			}
			if (state=='a'){
				awnser = awnser + a;
			}
			if (state=='b'){
				for(int j = 0; j< Integer.parseInt(finalnumber);j++){
					awnser = awnser + a;
				}
			}
		}
		System.out.println(awnser);
		return awnser;
	}

	public static void main(String[] args){
		new main();
	}
}
